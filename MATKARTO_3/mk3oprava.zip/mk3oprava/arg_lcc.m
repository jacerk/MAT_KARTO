clc
clear
hold on
axis equal
format long g

R = 1;

% Pole
vk = -61.3423389*pi/180; 
uk = -58.8630571*pi/180;

% Northern-most point
v1 = -36.9984758*pi/180;
u1 = -56.7295554*pi/180;

% Southern-most point
v2 = -22.259597*pi/180;
u2 = -66.7355685*pi/180;

% Transform to oblique aspect
[s1, d1] = uv_sd(u1, v1, uk, vk);
[s2, d2] = uv_sd(u2, v2, uk, vk);

% Constant value c of projection (14)
cn = log10(cos(s1))-log10(cos(s2));
cd = log10(tan(s2/2 + pi/4))-log10(tan(s1/2 + pi/4));
c = cn/cd;

% True parallel (14)
s0 = 1.3285;

% Constant value rho0 of projection (13)
Ro0_n = 2*R*cos(s0)*cos(s1)*(tan(s1/2 + pi/4))^c;
Ro0_d = c*(cos(s0)*(tan(s0/2 + pi/4))^c + cos(s1)*(tan(s1/2 + pi/4))^c);
Ro0 = Ro0_n/Ro0_d;

% Coordinates of P1, P2 in LCC (11), (12)
Ro1_n = (tan(s0/2 + pi/4))^c;
Ro1_d = (tan(s1/2 + pi/4))^c;
Ro1 = Ro0*Ro1_n/Ro1_d;

Ro2_n = (tan(s0/2 + pi/4))^c;
Ro2_d = (tan(s2/2 + pi/4))^c;
Ro2 = Ro0*Ro2_n/Ro2_d;

% Local linear scales (17)
m0 = (c*Ro0)/(R*cos(s0));
m1 = (c*Ro1)/(R*cos(s1));
m2 = (c*Ro2)/(R*cos(s2));

% Distortions
mju0 = m0-1;
mju1 = m1-1;
mju2 = m2-1;

% Distortions per km [in m]
mju0_km = mju0*1000
mju1_km = mju1*1000
mju2_km = mju2*1000

% Load points
B = load("argentina.txt");
u = B(:, 1) *pi/180;
v = B(:, 2) *pi/180;

% Convert to oblique aspect
[s, d] = uv_sd(u, v, uk, vk);

% Project argentina
[xn, yn] = lambert(R, s, d, s0, Ro0);
plot(xn, yn, 'b');

% Compute graticule
umin = -75*pi/180 ;
umax = -53*pi/180;
vmin = -55*pi/180;
vmax = -20*pi/180;
Du = 2.5*pi/180;
Dv = 2.5*pi/180;
du = 1*pi/180;
dv = 1*pi/180;

proj = @lambert;

[XM, YM, XP, YP] = graticule(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, Ro0, proj);
plot(XM', YM', 'k');
plot(XP', YP', 'k');

% Mesh gird
[ug, vg] = meshgrid(umin:du:umax, vmin:dv:vmax);

% Convert to oblique aspect
[sg, dg] = uv_sd(ug, vg, uk, vk);

% Project meshgrid
[xg, yg] = lambert(R, sg, dg, s0, Ro0);
%plot(xg, yg, 'o');

% Local linear scales
ro = Ro0 .* ((tan(s0/2 + pi/4)).^c ./ (tan(sg/2 + pi/4)).^c);

% Local linear scale
m = (c * ro) ./ (R * cos(sg));

% Distortion
mju = m-1;

% Distortions per km [in m]
mju_km = mju*1000;

% Contour lines
dz = 0.4;
[C, h] = contour(xg, yg, mju_km,[-50:dz:50], 'LineColor', 'r', 'Linewidth', 0.3);
% clabel(C, h,'Color', 'red');


[C, h] = contour(xg, yg, mju_km,[-50:dz*5:50], 'LineColor', 'r', 'Linewidth', 1.1);
clabel(C, h,'Color', 'red');

axis off