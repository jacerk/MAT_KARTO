clc
clear
hold on
axis equal
format long g

R = 1;
Ro0 = 0;

% Input points, Equator
v1 = -24.9037693*pi/180;
u1 = -60.7754481*pi/180;
v2 = -49.507969*pi/180;
u2 = -68.559877*pi/180;

%Southern-most point
v3 = -29.298157*pi/180;
u3 = -70.018329*pi/180;

%Northern-most point
v4 = -36.84708*pi/180;
u4 = -56.693885*pi/180;

% Pole (8, 9)
vk = atan2(tan(u1)*cos(v2)-tan(u2)*cos(v1), tan(u2)*sin(v1)-tan(u1)*sin(v2));
uk = atan2(-cos(v2-vk), tan(u2));

% Transform to oblique aspect
[s1, d1] = uv_sd(u1, v1, uk, vk);
[s2, d2] = uv_sd(u2, v2, uk, vk);
[s3, d3] = uv_sd(u3, v3, uk, vk);
[s4, d4] = uv_sd(u4, v4, uk, vk);

% True parallel (7)
s0 = acos(2*cos(s4)/(1+cos(s4)));

% Local linear scale (10)
m1 = cos(s0)/cos(s1);
m2 = cos(s0)/cos(s2);
m3 = cos(s0)/cos(s3);
m4 = cos(s0)/cos(s4);

% Distortions
mju1 = m1-1;
mju2 = m2-1;
mju3 = m3-1;
mju4 = m4-1;

% Distortions per km [in m]
mju1_km = mju1*1000
mju2_km = mju2*1000
mju3_km = mju3*1000
mju4_km = mju4*1000

% Load points
B = load("argentina.txt");
u = B(:, 1) *pi/180;
v = B(:, 2) *pi/180;

% Convert to oblique aspect
[s, d] = uv_sd(u, v, uk, vk);

% Project argentina
[xn, yn] = mercator(R, s, d, s0, Ro0);
plot(xn, yn, 'b');

% Compute graticule
umin = -75*pi/180;
umax = -52*pi/180;
vmin = -55*pi/180;
vmax = -15*pi/180;
Du = 5*pi/180;
Dv = 5*pi/180;
du = 0.1*pi/180;
dv = 0.1*pi/180;

proj = @mercator;

[XM, YM, XP, YP] = graticule(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, Ro0, proj);
plot(XM', YM', 'k');
plot(XP', YP', 'k');

% Mesh gird
[ug, vg] = meshgrid(umin:du:umax, vmin:dv:vmax);

% Convert to oblique aspect
[sg, dg] = uv_sd(ug, vg, uk, vk);

% Project meshgrid
[xg, yg] = mercator(R, sg, dg, s0, Ro0);
%plot(xg, yg, 'o');

% Local linear scale
m = cos(s0)./cos(sg);

% Distortion
mju = m-1;

% Distortions per km [in m]
mju_km = mju*1000;

%Contour lines
dz = 0.4;
[C, h] = contour(xg, yg, mju_km,[-50:dz:50], 'LineColor', 'r', 'Linewidth', 0.3);
% clabel(C, h,'Color', 'red');


[C, h] = contour(xg, yg, mju_km,[-50:dz*5:50], 'LineColor', 'r', 'Linewidth', 1.1);
clabel(C, h,'Color', 'red');

axis off