function [x, y] = lambert(R, s, d, s0, Ro0)
   % Lambert conic conform projection in oblique aspect
   c = sin(s0);
   
   ro = Ro0 .* ((tan(s0/2 + pi/4)).^c ./ (tan(s/2 + pi/4)).^c);
   eps = c .* d;

   x = -ro .* sin(eps);
   y = -ro .* cos(eps);
end