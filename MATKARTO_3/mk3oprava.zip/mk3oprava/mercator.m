function [x, y] = mercator(R, s, d, s0, Ro0)
   % Mercator projection in oblique aspect
   c = R .* cos(s0);

   x = -c .* d;
   y = R .* log(tan(s/2 + pi/4));
end