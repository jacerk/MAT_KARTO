clc
clear
hold on
axis equal
format long g

R = 1;
Ro0 = 0;

% Pole
uk = -64.707808*pi/180; 
vk = -38.541277*pi/180;

% Southern-most point
u1 = -66.186063*pi/180;
v1 = -21.801971*pi/180;


% Transform to oblique aspect
[s1, d1] = uv_sd(u1, v1, uk, vk);

psi1 = pi/2 - s1;

% Compute mju (multiplicant constant)
mju = (2*cos(psi1/2)^2)/(1+cos(psi1/2)^2);

% Psi0
psi0 = 2*acos(sqrt(mju));
s0 = pi/2 - psi0;

% Local linear scale
m1 = mju/(cos(psi1/2)^2);
m2 = mju/(cos(0)^2);
m0 = mju/(cos(psi0/2)^2);

% Distortion
mju1 = m1-1;
mju2 = m2-1;
mju0 = m0-1;

% Distortions per km [in m]
mju1_km = mju1*1000
mju2_km = mju2*1000
mju0_km = mju0*1000

% Load points
B = load("argentina.txt");
u = B(:, 1) *pi/180;
v = B(:, 2) *pi/180;

% Convert to oblique aspect
[s, d] = uv_sd(u, v, uk, vk);

% Project argentina
[xn, yn] = stereo(R, s, d, s0, Ro0);
plot(xn, yn, 'b');

% Compute graticule
umin = -75*pi/180 ;
umax = -53*pi/180;
vmin = -55*pi/180;
vmax = -20*pi/180;
Du = 5*pi/180;
Dv = 5*pi/180;
du = 0.1*pi/180;
dv = 0.1*pi/180;

proj = @stereo;

[XM, YM, XP, YP] = graticule(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, Ro0, proj);
plot(XM', YM', 'k');
plot(XP', YP', 'k');

% Mesh gird
[ug, vg] = meshgrid(umin:du:umax, vmin:dv:vmax);

% Convert to oblique aspect
[sg, dg] = uv_sd(ug, vg, uk, vk);

% Project meshgrid
[xg, yg] = stereo(R, sg, dg, s0, Ro0);
%plot(xg, yg, 'o');

% Local linear scales
psig = pi/2 - sg;
psi0 = pi/2 - s0;

% Local linear scale
m = (cos(psi0/2)^2)./(cos(psig/2).^2);

% Distortion
mju = m-1;

% Distortions per km [in m]
mju_km = mju*1000;

% Contour lines
dz = 0.4;
[C, h] = contour(xg, yg, mju_km,[-50:dz:50], 'LineColor', 'r', 'Linewidth', 0.3);
% clabel(C, h,'Color', 'red');


[C, h] = contour(xg, yg, mju_km,[-50:dz*5:50], 'LineColor', 'r', 'Linewidth', 1.1);
clabel(C, h,'Color', 'red');

axis off