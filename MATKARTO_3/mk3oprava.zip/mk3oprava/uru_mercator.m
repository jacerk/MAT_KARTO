clc
clear
hold on
axis equal
format long g

R = 1;
Ro0 = 0;

% Input points, Equator
u1 = -57.82421 *pi/180;
v1 = -32.04952 *pi/180;
u2 = -54.263153 *pi/180;
v2 = -33.780931 *pi/180;

% Northern-most point
u3 = -55.086862 *pi/180;
v3 = -30.948293 *pi/180;

% Southern-most point
u4 = -57.044461 *pi/180;
v4 = -34.843108 *pi/180;

% Pole (8, 9)
vk = atan2(tan(u1)*cos(v2)-tan(u2)*cos(v1), tan(u2)*sin(v1)-tan(u1)*sin(v2));
uk = atan2(-cos(v2-vk), tan(u2));

% Transform to oblique aspect
[s1, d1] = uv_sd(u1, v1, uk, vk);
[s2, d2] = uv_sd(u2, v2, uk, vk);
[s3, d3] = uv_sd(u3, v3, uk, vk);
[s4, d4] = uv_sd(u4, v4, uk, vk);

% True parallel (7)
s0 = acos(2*cos(s4)/(1+cos(s4)));

% Local linear scale (10)
m1 = cos(s0)/cos(s1);
m2 = cos(s0)/cos(s2);
m3 = cos(s0)/cos(s3);
m4 = cos(s0)/cos(s4);

% Distortions
mju1 = m1-1;
mju2 = m2-1;
mju3 = m3-1;
mju4 = m4-1;

% Distortions per km [in m]
mju1_km = mju1*1000
mju2_km = mju2*1000
mju3_km = mju3*1000
mju4_km = mju4*1000

% Load points
S = load("uruguay.txt");
u = S(:, 2) *pi/180;
v = S(:, 1) *pi/180;

% Convert to oblique aspect
[s, d] = uv_sd(u, v, uk, vk);

% Project uruguay
[xn, yn] = mercator(R, s, d, s0, Ro0);
plot(xn, yn, 'b');

% Compute graticule
umin = -58.5*pi/180 ;
umax = -53*pi/180;
vmin = -37*pi/180;
vmax = -28*pi/180;
Du = 0.5*pi/180;
Dv = 0.5*pi/180;
du = 0.1*pi/180;
dv = 0.1*pi/180;

proj = @mercator;

[XM, YM, XP, YP] = graticule(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, Ro0, proj);
plot(XM', YM', 'k');
plot(XP', YP', 'k');

% Mesh gird
[ug, vg] = meshgrid(umin:du:umax, vmin:dv:vmax);

% Convert to oblique aspect
[sg, dg] = uv_sd(ug, vg, uk, vk);

% Project meshgrid
[xg, yg] = mercator(R, sg, dg, s0, Ro0);

% Local linear scale
m = cos(s0)./cos(sg);

% Distortion
mju = m-1;

% Distortions per km [in m]
mju_km = mju*1000;

% Contour lines
dz1 = 0.05;
[C, h] = contour(xg, yg, mju_km, [-20:dz1:100], 'LineColor', 'r','LineWidth', 0.4);

dz2 = 0.2;
[C, h] = contour(xg, yg, mju_km, [-20:dz2:100], 'LineColor', 'r', 'LineWidth', 1.1);
clabel(C, h, 'Color', 'r');

axis off